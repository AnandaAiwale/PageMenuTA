//
//  ViewController.swift
//  PageViewCV
//
//  Created by King on 26/04/18.
//  Copyright © 2018 TripalA. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {
    
    @IBOutlet weak var menuBar: UIScrollView! // used for Set Menu
    @IBOutlet weak var menuBarVC: UIScrollView! // usde for Set Menu ViewController
    
    let screenWidth = UIScreen.main.bounds.size.width  // Used for Screen Width
    let DefaultEdgeInset:UIEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0)//Set edge insets to menu button
    let menuArray = ["Tom","Cat", "Jari","Anjal"] // Menu button titles
    let font = UIFont.systemFont(ofSize: 16.0)// Font size for button title text
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Add buttons to MenuScrollView:
        self.addButtonsToMenuScrollView(menuArray)
        
        self.menuBar.layer.borderWidth = 3.0 // used for Boder Width
        self.menuBar.layer.borderColor = UIColor.lightGray.cgColor // Used for borde Color
        self.menuBar.layer.borderColor = UIColor(red: 233.0/255.0, green: 253.0/255.0, blue:  111.0/255.0, alpha: 1.0).cgColor  //
        self.menuBar.layer.backgroundColor =  UIColor(red: 233.0/255.0, green: 253.0/255.0, blue: 111.0/255.0, alpha: 1.0).cgColor // used set menu Background color
        self.menuBar.layer.masksToBounds = true
        
        //Instantiate view controllers those want to add in Page Controller.
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let firstV = storyboard.instantiateViewController(withIdentifier: "FirstVC") as! FirstVC
        let SecodnV = storyboard.instantiateViewController(withIdentifier: "SecondVC") as! SecondVC
        let thiedV = storyboard.instantiateViewController(withIdentifier: "ThriedVC") as! ThriedVC
        let four = storyboard.instantiateViewController(withIdentifier: "AnjaliVC") as! AnjaliVC
        self.addControllersToMainScrollView([firstV,SecodnV,thiedV,four])
       
    }
    func addButtonsToMenuScrollView(_ array:[String]) {
        let bHeight: CGFloat = self.menuBar.bounds.size.height
        var cWidth: CGFloat = 0.0
        for i in 0...array.count - 1 {
            let bWidth: CGFloat = self.calculateButtonWidth(array[i], DefaultEdgeInset) // Width of button considering attributes
            let frame: CGRect = CGRect(x: cWidth, y: 0, width: bWidth, height: bHeight)
            let menuButton = self.createButtonProgramaticallyAndCustomise(array[i], frame, i)
            self.menuBar.addSubview(menuButton)
            //Add bottom view to button to show selected status
            let bottomViewFrame = CGRect(x: 0, y: menuButton.frame.size.height - 5, width: menuButton.frame.size.width, height: 5)
            let selectionView = self.createButtonBottomView(bottomViewFrame)
            menuButton.addSubview(selectionView)
            
            if i == 0 {
                menuButton.isSelected = true
                selectionView.isHidden = false
            } else {
                selectionView.isHidden = true
            }
            cWidth += bWidth
        }
        
        self.menuBar.contentSize = CGSize(width: cWidth, height: self.menuBar.bounds.size.height)
    }
    func addControllersToMainScrollView(_ viewController:[UIViewController]) {
        for i in 0...viewController.count - 1 {
            let vc = viewController[i]
            var frame = CGRect(x: 0, y: 0, width: self.menuBarVC.frame.size.width, height: self.menuBarVC.frame.size.height)
            frame.origin.x = screenWidth * CGFloat(i)
            vc.view.frame = frame
            self.addChildViewController(vc)
            self.menuBarVC.addSubview(vc.view)
            vc.didMove(toParentViewController: self)
        }
        self.menuBarVC.contentSize = CGSize(width: screenWidth * CGFloat(viewController.count), height:0)
        self.menuBarVC.delegate = self
        self.menuBarVC.isPagingEnabled = true
    }
    
    
    
    func createButtonProgramaticallyAndCustomise(_ title:String, _ frame: CGRect, _ tag: Int) -> UIButton {
        //Create button programatically and add to Menu ScrollView
        let button: UIButton = UIButton(type: .custom)
        button.frame = frame
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = font
        
        //Set selected and normat color propreties to button
        button.setTitleColor(UIColor.black, for: .normal)
        button.setTitleColor(UIColor.gray, for: .selected)
        button.addTarget(self, action: #selector(buttonTapped(sender:)), for: .touchUpInside)
        button.tag = tag
        
        return button
    }
    
    @objc func buttonTapped(sender: UIButton) {
        let bWidth: CGFloat = 0
        for case let btn as UIButton in self.menuBar.subviews {
            let btmView = btn.viewWithTag(999)
            if btn.tag == sender.tag {
                btn.isSelected = true
                btmView?.isHidden = false
            } else {
                btn.isSelected  = false
                btmView?.isHidden = true}
        }
        
        let width = screenWidth * CGFloat(sender.tag)
        self.menuBarVC.setContentOffset(CGPoint(x:width, y:0), animated: true)
        let xCordinate = screenWidth * CGFloat(sender.tag) * (bWidth / screenWidth) - bWidth
        self.menuBarVC.scrollRectToVisible(CGRect(x:xCordinate, y:0, width:screenWidth, height:self.menuBarVC.frame.size.height), animated: true)
    }
    func createButtonBottomView(_ btnViewFrame: CGRect) -> UIView {
        let bottomView = UIView(frame: btnViewFrame)
        bottomView.backgroundColor = UIColor.black
        bottomView.tag = 999
        return bottomView
    }
    
    func calculateButtonWidth(_ title: String, _ buttonEdgeInsets: UIEdgeInsets) -> CGFloat {
        
        let size: CGSize = title.size(withAttributes: [kCTFontAttributeName as NSAttributedStringKey: font])
        let dividedSize = (screenWidth / CGFloat(menuArray.count))
        return (dividedSize < size.width) ? (size.width + buttonEdgeInsets.left + buttonEdgeInsets.right) : (dividedSize + buttonEdgeInsets.left + buttonEdgeInsets.right)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

